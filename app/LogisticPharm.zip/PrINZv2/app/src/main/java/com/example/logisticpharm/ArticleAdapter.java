package com.example.logisticpharm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.logisticpharm.model.Article;
import com.example.logisticpharm.model.MedicineInfo;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ArticleAdapter extends FirebaseRecyclerAdapter<Article, ArticleAdapter.myviewholder> {

    public ArticleAdapter(@NonNull FirebaseRecyclerOptions<Article> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ArticleAdapter.myviewholder holder, @SuppressLint("RecyclerView") int position, @NonNull Article article)
    {
        holder.name.setText(article.getArticleName());

        holder.text.setText(article.getArticleText());//String.valueOf(
        holder.author.setText(article.getArticleAuthor());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Otwórz nową aktywność z treścią artykułu
                Intent intent = new Intent(view.getContext(), ArticleContentActivity.class);
                intent.putExtra("articleName", article.getArticleName());
                intent.putExtra("articleAuthor", article.getArticleAuthor());
                intent.putExtra("articleText", article.getArticleText());
                view.getContext().startActivity(intent);
            }
        });
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final DialogPlus dialogPlus=DialogPlus.newDialog(view.getContext())
                        .setContentHolder(new ViewHolder(R.layout.dialog_content))
                        .setExpanded(true,1100)
                        .create();

                View myview=dialogPlus.getHolderView();
                final EditText name=myview.findViewById(R.id.uimgurl);
                final EditText author=myview.findViewById(R.id.uname);
                final EditText text=myview.findViewById(R.id.ucourse);

                Button submit=myview.findViewById(R.id.usubmit);

                name.setText(article.getArticleName());
                text.setText(article.getArticleText());
                author.setText(article.getArticleAuthor());

                dialogPlus.show();

                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Map<String,Object> map=new HashMap<>();
                        map.put("articleName",name.getText().toString());
                        map.put("articleAuthor",author.getText().toString());
                        map.put("articleText",text.getText().toString());


                        FirebaseDatabase.getInstance().getReference().child("Article")
                                .child(getRef(position).getKey()).updateChildren(map)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        dialogPlus.dismiss();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        dialogPlus.dismiss();
                                    }
                                });
                    }
                });


            }
        });


        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(view.getContext());
                builder.setTitle("Delete Panel");
                builder.setMessage("Delete...?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        FirebaseDatabase.getInstance().getReference().child("Article")
                                .child(getRef(position).getKey()).removeValue();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                builder.show();
            }
        });

    } // End of OnBindViewMethod


    @NonNull
    @Override
    public ArticleAdapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowarticle,parent,false);
        return new ArticleAdapter.myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder
    { CircleImageView img;
        ImageView edit,delete;
        TextView name,author,text;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);

            //  img=(CircleImageView) itemView.findViewById(R.id.img1);
            name=(TextView)itemView.findViewById(R.id.medicineArticleShow);
            author=(TextView)itemView.findViewById(R.id.medicineAuthorShow);
            text=(TextView)itemView.findViewById(R.id.medicineTextShow);
            edit=(ImageView)itemView.findViewById(R.id.btnEdit);
            delete=(ImageView)itemView.findViewById(R.id.btnDelete);
        }
    }
}

