package com.example.logisticpharm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RecylcerShowArticle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recylcer_show_article);
    }
}