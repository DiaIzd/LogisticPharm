package com.example.logisticpharm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.logisticpharm.model.MedicineInfo;

import java.util.ArrayList;

public class MedicineShop extends AppCompatActivity {

    private ArrayList<MedicineInfo> medicines;
    private int currentPosition = 0;
    private TextView medicineNameTextView;
    private TextView medicineCostTextView;
    private TextView quantityTextView;
    private TextView totalCostTextView;
    private int quantity = 0;
    private double totalCost = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_shop);


        ArrayList<MedicineInfo> medicines = new ArrayList<>();
// Dodaj obiekty MedicineInfo do listy medicines

        Intent intent = new Intent(MedicineShop.this, MedicineShop.class);
        intent.putParcelableArrayListExtra("medicines", medicines);
        startActivity(intent);

        medicineNameTextView = findViewById(R.id.medicineNameTextView);
        medicineCostTextView = findViewById(R.id.medicineCostTextView);
        quantityTextView = findViewById(R.id.quantityTextView);
        totalCostTextView = findViewById(R.id.totalCostTextView);

        updateUI();

        Button addButton = findViewById(R.id.addButton);
        Button subtractButton = findViewById(R.id.subtractButton);
        Button nextButton = findViewById(R.id.nextButton);
        Button prevButton = findViewById(R.id.prevButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity++;
                totalCost += Double.parseDouble(medicines.get(currentPosition).getMedicineCost());
                updateUI();
            }
        });

        subtractButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (quantity > 0) {
                    quantity--;
                    totalCost -= Double.parseDouble(medicines.get(currentPosition).getMedicineCost());
                    updateUI();
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentPosition < medicines.size() - 1) {
                    currentPosition++;
                    quantity = 0;
                    totalCost = 0;
                    updateUI();
                }
            }
        });

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentPosition > 0) {
                    currentPosition--;
                    quantity = 0;
                    totalCost = 0;
                    updateUI();
                }
            }
        });
    }

    private void updateUI() {
        MedicineInfo currentMedicine = medicines.get(currentPosition);
        medicineNameTextView.setText(currentMedicine.getMedicineName());
        medicineCostTextView.setText(currentMedicine.getMedicineCost() + " PLN");
        quantityTextView.setText(String.valueOf(quantity));
        totalCostTextView.setText("Łączny koszt: " + totalCost + " PLN");
    }
}