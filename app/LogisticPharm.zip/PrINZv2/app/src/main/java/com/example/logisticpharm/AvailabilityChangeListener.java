package com.example.logisticpharm;

import static androidx.activity.result.ActivityResultCallerKt.registerForActivityResult;
import static androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale;

import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.annotations.Nullable;


public class AvailabilityChangeListener extends ContextWrapper {
    private DatabaseReference favoritesRef;
    private Context context;
    public static final String channelID_before = "startMission";
    public static final String channelName_before = "EdugStartMission";

    private NotificationManager mManager;

    public AvailabilityChangeListener(Context context, DatabaseReference favoritesRef) {
        super(context);
        this.context = context;
        this.favoritesRef = favoritesRef;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createChannel();
        }
        startListeningForChanges();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createChannel() {
        NotificationChannel channelBefore = new NotificationChannel(channelID_before, channelName_before, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channelBefore);
    }

    public NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }
    public NotificationCompat.Builder getChannelNotificationBefore(String title, String content) {
        Intent resultIntent = new Intent(this, RecyclerViewUser.class);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(this, 1, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, channelID_before)
                .setContentTitle(title)
                .setContentText(content)
                .setAutoCancel(true)
                .setContentIntent(resultPendingIntent);}
    private void startListeningForChanges() {
        favoritesRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                // ...
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                int medicineBoxes = snapshot.child("medicineBoxes").getValue(Integer.class);
                String userId = snapshot.getKey();

                String availabilityStatus = calculateAvailabilityStatus(medicineBoxes);
                if ("Dostępny".equals(availabilityStatus)) {
                    sendNotificationToUser(userId, "Twój ulubiony lek jest teraz dostępny.");
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                // ...
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                // ...
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // ...
            }
        });
    }

    private String calculateAvailabilityStatus(int medicineBoxes) {
        if (medicineBoxes == 0) {
            return "Niedostępny";
        } else if (medicineBoxes < 3) {
            return "Ciężko dostępny";
        } else if (medicineBoxes >= 3 && medicineBoxes <= 6) {
            return "Średnio dostępny";
        } else {
            return "Dostępny";
        }
    }

    private void sendNotificationToUser(String userId, String message) {
        Intent resultIntent = new Intent(context, RecyclerViewUser.class);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(context, 1, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context, channelID_before)
                        .setContentTitle("Lek dostępny!")
                        .setContentText(message)
                        .setAutoCancel(true)
                        .setContentIntent(resultPendingIntent);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(0, notificationBuilder.build());
    }
}
  /*  private void sendNotificationToUser(String userId) {
        String channelId = "default_channel_id";
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Default Channel", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        Intent intent = new Intent("com.example.logisticpharm.SHOW_NOTIFICATION");
        intent.putExtra("notification_message", "Twój ulubiony lek jest teraz dostępny.");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context, channelId)
                        //.setSmallIcon(R.drawable.ic_notification)
                        .setContentTitle("Lek dostępny!")
                        .setContentText("Twój ulubiony lek jest teraz dostępny.")
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(0, notificationBuilder.build());
    }
}
*/
