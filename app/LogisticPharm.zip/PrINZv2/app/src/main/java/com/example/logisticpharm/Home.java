package com.example.logisticpharm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {
    Button btnAddMedicine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Pobieramy referencję do przycisku po ID
        btnAddMedicine = findViewById(R.id.addMedicine);

        btnAddMedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tworzymy nową intencję (Intent), aby przejść do aktywności EmployeeAddMedicine
                Intent intent = new Intent(Home.this, EmployeeAddMEdicine.class);
                startActivity(intent);
            }
        });
    }
}