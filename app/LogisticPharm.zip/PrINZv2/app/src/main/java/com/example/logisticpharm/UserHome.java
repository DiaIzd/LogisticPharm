package com.example.logisticpharm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.logisticpharm.userGUI.BottomNavigationHelperUser;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class UserHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
       // BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
       // BottomNavigationHelperUser.setupBottomNavigation(this, bottomNavigationView);

    }
}