package com.example.logisticpharm;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.logisticpharm.model.MedicineInfo;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdapterShowUser extends FirebaseRecyclerAdapter<MedicineInfo, AdapterShowUser.myviewholderUser>
{

    public AdapterShowUser(@NonNull FirebaseRecyclerOptions<MedicineInfo> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholderUser holder, @SuppressLint("RecyclerView") int position, @NonNull MedicineInfo medicineInfo)
    {
        holder.name.setText(medicineInfo.getMedicineName());
        holder.kind.setText(medicineInfo.getMedicineKind());
        holder.cost.setText(medicineInfo.getMedicineCost());//String.valueOf(
        holder.inside.setText(medicineInfo.getMedicineInside());
        //  holder.box.setText(medicineInfo.getMedicineBoxes());
        //Glide.with(holder.img.getContext()).load(model.getPurl()).into(holder.img);
        String availabilityStatus = medicineInfo.getAvailabilityStatus();
        holder.availability.setText(availabilityStatus);
        holder.availability.setTextColor(ContextCompat.getColor(holder.availability.getContext(), medicineInfo.getAvailabilityStatusColor()));
        String medicineKey = getRef(position).getKey(); // Pobierz klucz danego leku
        DatabaseReference medicineRef = FirebaseDatabase.getInstance().getReference()
                .child("MedicineInfo")
                .child(medicineKey);

        medicineRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    MedicineInfo medicineInfo = snapshot.getValue(MedicineInfo.class);
                    // Teraz możesz użyć medicineInfo w holderze
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Obsługa błędów
            }
        });


        holder.addToFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(view.getContext());
                builder.setTitle("Dodanie do ulubionych");
                builder.setMessage("Czy na pewno dodać do ulubionych?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                        if (currentUser != null) {
                            String userId = currentUser.getUid();
                            DatabaseReference favoritesRef = FirebaseDatabase.getInstance().getReference().child("Favorites").child(userId);
                            favoritesRef.child(getRef(position).getKey()).setValue(true);
                        }
                    }
                });


                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                builder.show();
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                if (currentUser != null) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Delete Panel");
                    builder.setMessage("Delete...?");

                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String userId = currentUser.getUid();
                            DatabaseReference favoritesRef = FirebaseDatabase.getInstance().getReference().child("Favorites").child(userId);
                            favoritesRef.child(getRef(position).getKey()).removeValue()
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Toast.makeText(view.getContext(), "Usunięto z ulubionych", Toast.LENGTH_SHORT).show();
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(view.getContext(), "Błąd przy usuwaniu z ulubionych", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });

                    builder.show();
                } else {
                    // Użytkownik niezalogowany, wyświetl odpowiedni komunikat lub zablokuj operację
                    Toast.makeText(view.getContext(), "Aby usunąć z ulubionych, zaloguj się.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    } // End of OnBindViewMethod



    @NonNull
    @Override
    public myviewholderUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowuser,parent,false);
        return new myviewholderUser(view);
    }

    class myviewholderUser extends RecyclerView.ViewHolder
    { CircleImageView img;
        ImageView edit,delete,addToFavorite;
        TextView name,kind,cost,inside,availability,box;
        public myviewholderUser(@NonNull View itemView)
        {
            super(itemView);
            //  img=(CircleImageView) itemView.findViewById(R.id.img1);
            name=(TextView)itemView.findViewById(R.id.medicineNameShowUser);
            kind=(TextView)itemView.findViewById(R.id.medicineKindShowUser);
            cost=(TextView)itemView.findViewById(R.id.medicineCostShowUser);
            inside=(TextView)itemView.findViewById(R.id.medicineInsideShowUser);
            //box=(TextView)itemView.findViewById(R.id.medicineBoxesShow);
            availability = itemView.findViewById(R.id.medicineAvailabilityShowUser); // Inicjalizujemy availability
           // edit=(ImageView)itemView.findViewById(R.id.btnEdit);
            delete=(ImageView)itemView.findViewById(R.id.btnDeleteFavorite);
            addToFavorite=(ImageView)itemView.findViewById(R.id.btnAddFavorite);
        }
    }
}
