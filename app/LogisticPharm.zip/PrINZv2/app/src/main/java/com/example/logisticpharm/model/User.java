package com.example.logisticpharm.model;

public class User {
    // string variable for
    // storing employee name.
    private  String userName;
    String key;
    // string variable for storing
    // employee contact number
    private  String userLastName;

    // string variable for storing
    // employee address.
    private  String userEmail;

    public User() {

    }

    // created getter and setter methods
    // for all our variables.
    public  String getUserName() {
        return userName;
    }
    public String getKey(){return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public  String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public  String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

}
