package com.example.logisticpharm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;

import com.example.logisticpharm.model.MedicineInfo;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;




import android.os.Bundle;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.logisticpharm.model.MedicineInfo;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class UserFavorite extends AppCompatActivity
{
    private RecyclerView recviewUser;
    private AdapterShowUser adapterUser;
    private SearchView searchViewUser;
    private DatabaseReference favoritesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view_user);
        setTitle("");

        recviewUser = findViewById(R.id.recviewUser);
        searchViewUser = findViewById(R.id.searchViewUser);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            favoritesRef = FirebaseDatabase.getInstance().getReference()
                    .child("Favorites")
                    .child(userId);
        }

        recviewUser.setLayoutManager(new LinearLayoutManager(this));

        searchViewUser.clearFocus();
        searchViewUser.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterList(s);
                return true;
            }            private void filterList(String s) {
                FirebaseRecyclerOptions<MedicineInfo> options =
                        new FirebaseRecyclerOptions.Builder<MedicineInfo>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("MedicineInfo").orderByChild("medicineName").startAt(s).endAt(s+"\uf8ff"), MedicineInfo.class)
                                .build();

                adapterUser=new AdapterShowUser(options);
                adapterUser.startListening();
                recviewUser.setAdapter(adapterUser);

            }
        });

        if (favoritesRef != null) {
            favoritesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    List<String> favoriteKeys = new ArrayList<>();
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        favoriteKeys.add(ds.getKey());
                    }

                    Query query = FirebaseDatabase.getInstance().getReference()
                            .child("MedicineInfo");

                    FirebaseRecyclerOptions<MedicineInfo> options =
                            new FirebaseRecyclerOptions.Builder<MedicineInfo>()
                                    .setQuery(query, MedicineInfo.class)
                                    .build();

                    adapterUser = new AdapterShowUser(options) {
                        @Override
                        protected void onBindViewHolder(@NonNull myviewholderUser holder, int position, @NonNull MedicineInfo medicineInfo) {
                            if (favoriteKeys.contains(getRef(position).getKey())) {
                                super.onBindViewHolder(holder, position, medicineInfo);
                            } else {
                                holder.itemView.setVisibility(View.GONE);
                                holder.itemView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
                            }
                        }
                    };
                    recviewUser.setAdapter(adapterUser);
                    adapterUser.startListening();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Obsługa błędu
                }
            });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adapterUser != null) {
            adapterUser.startListening();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adapterUser != null) {
            adapterUser.stopListening();
        }
    }

}