package com.example.logisticpharm.model;

public class Article {

    private  String articleName;
    String key;

    private  String articleText;


    private  String articleTitle;


    private  String articleAuthor;

    public Article() {

    }

    // created getter and setter methods
    // for all our variables.
    public  String getArticleName() {
        return articleName;
    }
    public String getKey(){return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public void setArticleName(String articleName) {
        this.articleName = articleName;
    }

    public  String getArticleText() {
        return articleText;
    }

    public void setArticleText(String articleText) {
        this.articleText = articleText;
    }

    public  String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }
    //public double getMedicineCost() {
    //     return medicineCost;
    //}

    // public void setMedicineCost(double medicineCost) {
    //     this.medicineCost = medicineCost;
    // }
    public String getArticleAuthor() {
        return articleAuthor;
    }
    public void setArticleAuthor(String articleAuthor) {
        this.articleAuthor = articleAuthor;
    }


}
