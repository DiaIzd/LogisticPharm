package com.example.logisticpharm.employeeGUI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.logisticpharm.AdapterShow;
import com.example.logisticpharm.ArticleAdd;
import com.example.logisticpharm.ArticleShow;
import com.example.logisticpharm.EmployeeAddMEdicine;
import com.example.logisticpharm.LoginActivity;
import com.example.logisticpharm.model.MedicineInfo;
import com.example.logisticpharm.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;


public class RecylcerShow extends AppCompatActivity
{
    private BottomNavigationView bottomNavigationView;
    RecyclerView recview;
    AdapterShow adapter;
    SearchView searchViewa;
FloatingActionButton fb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recylcer_show);
        setTitle("");
        searchViewa = findViewById(R.id.searchView);
        bottomNavigationView = findViewById(R.id.bottomNavigationViewEmployee);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if(itemId == R.id.action_dodaj){
                    startActivity(new Intent(RecylcerShow.this, EmployeeAddMEdicine.class));
                    return true;
                } else if (itemId == R.id.action_logout) {
                    FirebaseAuth.getInstance().signOut();
                    Intent intent = new Intent(RecylcerShow.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                }else if(itemId == R.id.action_article){
                    startActivity(new Intent(RecylcerShow.this, ArticleAdd.class));
                     return true;
                  }else if(itemId == R.id.action_articleShow)

            {
                startActivity(new Intent(RecylcerShow.this, ArticleShow.class));
                return true;
            }else
                    return false;

                //case R.id.action_article:
                    //    startActivity(new Intent(RecylcerShow.this, SearchActivity.class));
                    //   return true;


            }
        });
        searchViewa.clearFocus();
        searchViewa.setOnQueryTextListener(new SearchView.OnQueryTextListener(){
    @Override
    public boolean onQueryTextSubmit(String s){
        return false;
    }
    @Override
    public boolean onQueryTextChange(String s){
        filterList(s);
        return true;
    }

    private void filterList(String s) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("MedicineInfo");

        String query = s.toUpperCase(); // Konwertujemy zapytanie na małe litery

        Query filteredQuery = reference.orderByChild("medicineName")
                .startAt(query)
                .endAt(query + "\uf8ff");

        FirebaseRecyclerOptions<MedicineInfo> options =
                new FirebaseRecyclerOptions.Builder<MedicineInfo>()
                        .setQuery(filteredQuery, MedicineInfo.class)
                        .build();
        adapter=new AdapterShow(options);
        adapter.startListening();
        recview.setAdapter(adapter);
    }
});

        recview=(RecyclerView)findViewById(R.id.recview);
        recview.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<MedicineInfo> options =
                new FirebaseRecyclerOptions.Builder<MedicineInfo>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("MedicineInfo"), MedicineInfo.class)
                .build();
        //DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("medicineInfo");
        //FirebaseRecyclerOptions<MedicineInfo> options =
          //      new FirebaseRecyclerOptions.Builder<MedicineInfo>()
            //            .setQuery(reference, snapshot -> {
              //              MedicineInfo medicineInfo = snapshot.getValue(MedicineInfo.class);
                //            medicineInfo.setKey(snapshot.getKey());
                  //          return medicineInfo;
                    //    })
                      //  .build();
        adapter=new AdapterShow(options);
        recview.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }


/*  //  @Override
   // public boolean onCreateOptionsMenu(Menu menu)
   // {
      //  getMenuInflater().inflate(R.menu.search_menu,menu);

      //  MenuItem item=menu.findItem(R.id.search1);

        //SearchView searchView=(SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processSearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processSearch(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    private void processSearch(String s)
    {
        FirebaseRecyclerOptions<MedicineInfo> options =
                new FirebaseRecyclerOptions.Builder<MedicineInfo>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("MedicineInfo").orderByChild("medicineName").startAt(s).endAt(s+"\uf8ff"), MedicineInfo.class)
                        .build();

        adapter=new AdapterShow(options);
        adapter.startListening();
        recview.setAdapter(adapter);

    }*/


}