package com.example.logisticpharm.userGUI;

import static com.example.logisticpharm.R.id.*;
import static com.example.logisticpharm.R.id.action_logout;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.MenuItem;

import androidx.annotation.NonNull;

import com.example.logisticpharm.LoginActivity;
import com.example.logisticpharm.UserFavorite;
import com.example.logisticpharm.UserHome;
import com.example.logisticpharm.UserProfile;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class BottomNavigationHelperUser {
    /*public static void setupBottomNavigation(final Activity activity, BottomNavigationView bottomNavigationView) {
        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @SuppressLint("NonConstantResourceId")
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        int id = item.getItemId();
                            if(id == action_home) {
                                // Przejdź do aktywności HomeActivity po kliknięciu ikony "Home"
                                activity.startActivity(new Intent(activity, UserHome.class));
                                return true;
                            } else if (id == action_profile) {
                                // Przejdź do aktywności ProfileActivity po kliknięciu ikony "Profile"
                                activity.startActivity(new Intent(activity, UserProfile.class));
                                return true;
                            } else if (id ==action_ulubione) {
                                // Przejdź do aktywności SettingsActivity po kliknięciu ikony "Settings"
                                activity.startActivity(new Intent(activity, UserFavorite.class));
                                return true;
                            } else if (id ==action_logout) {
                                // Obsługa kliknięcia ikony "Logout"
                                logoutUser(activity);
                                return true;
                            }

                        return false;
                    }
                }
        );
    }

    private static void logoutUser(Activity activity) {
        // Wylogowanie użytkownika
        FirebaseAuth.getInstance().signOut();
        // Przekierowanie użytkownika do ekranu logowania (LoginActivity)
        Intent intent = new Intent(activity, LoginActivity.class);
        activity.startActivity(intent);
        activity.finish(); // Opcjonalnie, jeśli chcesz uniemożliwić użytkownikowi powrót do MainActivity po wylogowaniu.
    }*/
}