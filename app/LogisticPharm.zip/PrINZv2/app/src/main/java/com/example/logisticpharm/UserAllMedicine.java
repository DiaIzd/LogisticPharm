package com.example.logisticpharm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserAllMedicine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_all_medicine);
    }
}