package com.example.logisticpharm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DatabaseReference;


public class AlertReceive extends BroadcastReceiver {
        private DatabaseReference favoritesRef;  // Dodaj pole favoritesRef

        public AlertReceive(DatabaseReference favoritesRef) {
            this.favoritesRef = favoritesRef;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String titleNotifBefore = intent.getStringExtra("NOTIF_TITLE_BEFORE");
            String contentNotifBefore = intent.getStringExtra("NOTIF_CONTENT_BEFORE");

            AvailabilityChangeListener availabilityChangeListener = new AvailabilityChangeListener(context, favoritesRef);
            NotificationCompat.Builder notificationBefore = availabilityChangeListener.getChannelNotificationBefore(titleNotifBefore, contentNotifBefore);
            availabilityChangeListener.getManager().notify(1, notificationBefore.build());
        }
    }